-----------------------------------------------------------------------------------------
Hi, Thanks for purchase our item Tetra - Multipurpose Landing Page Template
-----------------------------------------------------------------------------------------


Included:

	HTML (6 Layout Styles )
	Documentation (Template help documentation)
	PSD (logo.psd)


-----------------------------------------------------------------------------------------
Features:
-----------------------------------------------------------------------------------------


	Fully Responsive Layout (PC, Tablet and Mobile phone)
	Based on Twitter Bootstrap 3.3.6
	jQuery-2.2.0
	12 Columns Grid System
	HTML5/CSS3 W3C valid
	Clean and Ultra Modern Design
	5 Layout Styles
	Seo Optimized for Search Engine
	Google Analytics Ready	
	Modern Responsive Mobile Navigation
	PrettyPhoto Lightbox Plugin Integration
	Pricing Tables, Team, Statistic Counter, Flex Slider Integration
	Font Awesome Retina Ready 400+ Vector Icons v4.5.0
	Working PHP Contact Form
	Working PHP Register Form
	Contact Form Validation
	Working MailChimp Subscribe Form
	MailChimp Form Validation
	Over 600 Google web fonts you can use
	and much more ...

		
-----------------------------------------------------------------------------------------

Template logo font : 

Title: League Spartan http://www.fontsquirrel.com/fonts/league-spartan (FREE)

-----------------------------------------------------------------------------------------


Best Regards
DSAThemes

http://themeforest.net/user/DSAThemes
DSAThemes <dsathemes@gmail.com>
http://www.dsathemes.com/
